import { IsDate, IsDateString, IsIn, IsString } from "class-validator"

export class CreateApiDto {
    @IsString()
    name: string
    @IsIn(["M", "F"])
    gender?: string
    @IsDateString()
    birth_date: Date 
}
