import { faker } from '@faker-js/faker';
import { members, PrismaClient } from '@prisma/client';

const prisma = new PrismaClient


async function main(){

    const members: members[] = await prisma.members.findMany()

    for(let i = 0; i < 15; i++){
        await prisma.payment.create({
            data: {
                member_id: faker.helpers.arrayElement(members).id,
                amount: Number(faker.finance.amount()),
                paid_at: faker.date.recent()
            }
        })
    }
}


main()
    .catch(e =>{
        console.error(e);
        process.exit(1);
    })
    .finally( async () => {
        await prisma.$disconnect()
    })
    